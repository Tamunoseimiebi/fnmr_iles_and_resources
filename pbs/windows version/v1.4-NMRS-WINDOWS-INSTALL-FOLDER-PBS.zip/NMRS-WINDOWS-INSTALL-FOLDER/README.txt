Installation
1. Copy this folder to your preferred installation directory.
2. open command prompt as administrator.
3. cd to this directory.
4. run NMRS-Bio.exe install
5. If the above command execute without errors then the installation was successfully and the service should be available on windows services.
6. Here are some sample command to start, restart, uninstall and install the service.

NMRS-Bio.exe restart
NMRS-Bio.exe start
NMRS-Bio.exe uninstall
NMRS-Bio.exe install


Configuration
The config folder contains a configuration file, below describe the detail of each configuration.

1. server.port - (DO NOT MODIFY THIS)
2. app.server - (This is the Database server host)
3. app.dbname - (This is the openmrs database name)
4. 
app.username - (This is the database username)
5. app.password - (This is the database password)
6. app.dbport - (This is the database server port)

Note: Restart this service after editing the configuration file.

Miscellaneous
1. Use http://localhost:2018 to check if service is running.
2. Use http://localhost:2018/server to view the details of the current configuration.

